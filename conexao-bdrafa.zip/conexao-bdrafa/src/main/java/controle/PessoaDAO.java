package controle;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import modelo.Pessoa;

public class PessoaDAO {

	public boolean inserir(Pessoa p) {
		// Intanciar a Classe
		Conexao c = Conexao.getInstancia();
		
		// Abrir a conexao com o banco de dados
		Connection con = c.conectar();
		
		String query = "INSERT INTO pessoa (Idadepessoa, Primeironome, Ultimonome, Cpfpessoa) VALUES (?, ?, ?, ?)";
		
		
		try {
			PreparedStatement ps = con.prepareStatement(query);
			ps.setInt(1, p.getIdadepessoa());
			ps.setString(2,  p.getPrimeironome());
			ps.setString(3,  p.getUltimonome());
			ps.setInt(4, p.getCpfpessoa());
			
			ps.executeUpdate();
			
			c.fecharConexao();
			
			return true;
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
				
		return false;
	}
	
}
