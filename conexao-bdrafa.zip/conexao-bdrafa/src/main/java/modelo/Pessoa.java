package modelo;

public class Pessoa {

	private int idadepessoa;
	private int cpfpessoa;
	private String primeironome;
	private String ultimonome;
	public int getIdadepessoa() {
		return idadepessoa;
	}
	public void setIdadepessoa(int idadepessoa) {
		this.idadepessoa = idadepessoa;
	}
	public int getCpfpessoa() {
		return cpfpessoa;
	}
	public void setCpfpessoa(int cpfpessoa) {
		this.cpfpessoa = cpfpessoa;
	}
	public String getPrimeironome() {
		return primeironome;
	}
	public void setPrimeironome(String primeironome) {
		this.primeironome = primeironome;
	}
	public String getUltimonome() {
		return ultimonome;
	}
	public void setUltimonome(String ultimonome) {
		this.ultimonome = ultimonome;
	}

	

}
